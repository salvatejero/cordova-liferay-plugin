Basic Example cordova-liferay-plugin 
======================

This is a Basic Example of use Cordova Liferay Plugin